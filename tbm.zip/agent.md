
# Requested System Modifications & Enhancements

## Important Instruction

**Do NOT rewrite, replace, or unnecessarily modify the existing codebase, architecture, UI design, database structure, or working functionality.**

The purpose of this request is to **modify and enhance the existing system** by adding the features and corrections listed below.

Keep the existing design, layout, navigation style, colors, components, and functionality wherever possible. Only make the changes necessary to implement the requirements below.

All newly added features must properly integrate with the existing system rather than functioning as disconnected pages.

---

# 1. Items / Products / Stock

Enhance the existing Items/Products functionality.

### Requirements

* Users should be able to add products/items they want to purchase or are currently viewing.
* Users should be able to upload/add a product image.
* Product images should be properly stored and displayed throughout the system.
* Products should have appropriate information such as:

  * Product name
  * Product image
  * Description
  * Category
  * Selling price
  * Purchase price/cost
  * Quantity/stock
  * SKU/product code where applicable
  * VAT
  * Status
* Products should connect properly with:

  * Inventory
  * Sales
  * Purchases
  * Invoices
  * Sales receipts
  * Purchase orders
  * Bills

Avoid creating duplicate product systems if one already exists. Extend the existing product/item functionality.

---

# 2. Sales Module

Add a dedicated **Sales** section in the main navigation.

The Sales section should have a dropdown containing:

1. Customers
2. Sales Orders
3. Sales Receipts
4. Payments Received
5. Quotes
6. Invoices
7. Credit Notes

### Sales Requirements

All Sales subsections should be properly connected.

For example:

**Customer → Quote → Sales Order → Invoice → Payment → Receipt**

Where applicable, sales transactions should automatically affect inventory/stock.

The system should maintain proper records of:

* Customer information
* Products sold
* Quantities
* Prices
* Discounts where applicable
* VAT
* Total amount
* Payment status
* Outstanding balance
* Invoice status
* Stock reduction

---

# 3. Purchases Module

Add a dedicated **Purchases** section in the main navigation.

The Purchases section should have a dropdown containing:

1. Vendors
2. Expenditures
3. Purchase Orders
4. Bills
5. Payments Made
6. Creditors

### Purchase Requirements

Purchases should properly connect with Inventory/Stock.

For example:

**Vendor → Purchase Order → Bill → Payment → Inventory Stock Increase**

The system should maintain proper records of:

* Vendor information
* Products purchased
* Quantities
* Purchase cost
* VAT
* Total amount
* Payment status
* Outstanding balance
* Creditor information
* Stock received

---

# 4. Invoice Printing

When an invoice is opened/viewed, there must be a clearly visible:

**Print Invoice**

button.

The print functionality should produce a clean, professional invoice suitable for printing or saving as PDF.

The printed invoice should contain the necessary information, including:

* Business/company information
* Customer information
* Invoice number
* Invoice date
* Due date where applicable
* Products/items
* Quantity
* Unit price
* Subtotal
* VAT
* Discount where applicable
* Grand total
* Payment status
* Outstanding balance

Do not remove the existing invoice functionality. Add the print functionality to it.

---

# 5. Feedback System

Add a **Feedback** button/section for users.

### User Side

Users should be able to:

* Open the Feedback section
* Submit feedback directly to the Administrator
* Enter a subject/title
* Enter their message
* Submit the feedback
* See confirmation that the feedback was successfully submitted

### Administrator Side

The Administrator should be able to:

* View submitted feedback
* Open individual feedback
* See who submitted it
* See the submission date/time
* Mark feedback as reviewed/resolved where appropriate
* Manage/delete feedback where necessary

The feedback system should be connected to the existing user/admin authentication system.

---

# 6. Subscription Packages

The subscription system must implement the **actual rules, limits, and features of each subscription package**.

Do not simply display subscription plans visually.

Each package must have actual functionality behind it.

For example, if a package has limits on:

* Number of users
* Number of products
* Number of customers
* Number of vendors
* Number of invoices
* Number of sales transactions
* Number of purchase transactions
* Storage
* Reports
* Other system modules

Those limits must actually be enforced by the system.

---

# 7. Subscription Package Breakdown

Each subscription package must clearly display its specific features and restrictions.

The package details should show:

### Package Name

### Price

### Billing Period

### Included Features

### Usage Limits

### Restrictions

### Available Modules

### Number of Allowed Users

### Number of Allowed Products/Items

### Other applicable limits

The system should not merely show a generic description such as "Premium Package includes more features."

Instead, users should be able to clearly understand exactly what they are paying for.

For example:

* ✓ Inventory Management
* ✓ Sales Management
* ✓ Purchase Management
* ✓ Invoicing
* ✓ Reports
* ✓ Customer Management
* ✕ Advanced Reports
* Maximum 500 Products
* Maximum 5 Users
* etc.

**The displayed package rules and the actual system restrictions must match.**

If a user reaches a package limit, the system should clearly notify them and prevent the restricted action where appropriate.

Administrators should be able to configure/update package features and limits.

---

# 8. VAT

Set the system VAT rate to:

**18%**

VAT calculations should be applied consistently wherever VAT is applicable, including:

* Sales
* Invoices
* Quotes where applicable
* Purchases
* Bills
* Reports
* Receipts

VAT should be calculated correctly and displayed clearly.

Where possible, avoid hard-coding the VAT percentage throughout the system. Make it configurable from the appropriate system/admin settings so the Administrator can update it in the future if required.

---

# 9. POS

Remove the existing POS functionality **or simplify it significantly**.

The POS should not make the system complicated for the intended users.

If POS is retained, it should be extremely simple and intuitive.

The simplified POS should focus on essential operations such as:

1. Select/search product
2. Enter quantity
3. Add to cart
4. Calculate subtotal
5. Apply VAT
6. Show total
7. Select payment method
8. Complete sale
9. Generate receipt
10. Automatically update inventory

Avoid unnecessary complicated POS features.

If the existing POS duplicates functionality already covered by the Sales module, prioritize the Sales module and simplify/remove the duplicate functionality.

---

# 10. Inventory / Stock Management

Add a proper dedicated:

**Inventory / Stock Management**

section.

Inventory must be connected to the Products, Sales, and Purchases modules.

### Inventory should support:

* Product/item list
* Product images
* SKU/product code
* Categories
* Current stock quantity
* Purchase price
* Selling price
* Stock-in
* Stock-out
* Stock adjustments
* Low-stock notifications
* Stock history
* Inventory valuation where applicable
* Product status
* Search and filtering

### Automatic Stock Updates

The system should automatically update stock.

#### When a purchase is received:

**Stock increases**

#### When a sale is completed:

**Stock decreases**

#### When a sales return/credit note is processed:

**Stock should be adjusted appropriately**

#### When a purchase return/credit is processed:

**Stock should be adjusted appropriately**

Inventory should therefore provide an accurate representation of the actual available stock.

---

# 11. Inventory Transaction History

Each product should have a stock movement/history record showing relevant transactions.

For example:

| Date   | Type          | Reference | Quantity | Balance |
| ------ | ------------- | --------- | -------- | ------- |
| Sept 1 | Opening Stock | —         | +100     | 100     |
| Sept 2 | Purchase      | PO-001    | +50      | 150     |
| Sept 2 | Sale          | INV-001   | -5       | 145     |
| Sept 3 | Sale          | INV-002   | -10      | 135     |

This should make it easy for administrators to understand where stock came from and where it went.

---

# 12. Module Integration

The most important requirement is that the modules should work together.

The system should follow a logical business flow:

### Products

↓

### Inventory

Purchases:

**Vendor → Purchase Order → Bill → Payment → Stock Increase**

Sales:

**Customer → Quote → Sales Order → Invoice → Payment → Receipt → Stock Decrease**

Returns:

**Credit Note → Inventory Adjustment → Account Balance Adjustment**

All relevant transactions should be reflected in the appropriate reports and dashboards.

---

# 13. Dashboard & Reports

Where the existing dashboard already contains analytics, extend it rather than replacing it.

The dashboard should be able to reflect relevant information such as:

* Total Sales
* Total Purchases
* Total Revenue
* Outstanding Invoices
* Payments Received
* Payments Made
* Total Expenses
* Number of Products
* Current Stock
* Low Stock Items
* Customers
* Vendors
* Creditors
* Recent Transactions

Charts and statistics should use actual system data.

Do not use fake/static numbers where the existing application is expected to display real database information.

---

# 14. User Experience

Keep the existing premium UI/UX and visual identity.

The new functionality should be:

* Clean
* Professional
* Responsive
* Easy to understand
* Consistent with the existing design
* Mobile-friendly
* Desktop-friendly
* Easy for non-technical users

Do not introduce unnecessary complexity.

Use clear:

* Buttons
* Dropdowns
* Forms
* Tables
* Search
* Filters
* Status badges
* Notifications
* Confirmation dialogs
* Empty states
* Validation messages

---

# 15. Permissions & Access Control

Respect the existing authentication and role/permission system.

Users should only be able to access the modules and actions permitted by their role and subscription.

For example:

* Administrator → Full management access
* Normal user → Only permitted operations
* Restricted subscription → Only permitted package features

Do not bypass existing authorization/security logic.

---

# 16. Validation & Error Handling

All new functionality must include proper validation.

Examples:

* Prevent selling products that are unavailable when stock control is enabled.
* Prevent invalid quantities.
* Prevent invalid prices.
* Validate uploaded product images.
* Validate invoice information.
* Validate customer/vendor information.
* Prevent unauthorized access.
* Prevent users from bypassing subscription limits.
* Show clear error/success messages.

---

# 17. Final Implementation Rule

**Do not rebuild the application from scratch.**

**Do not change working functionality unnecessarily.**

**Do not remove existing features unless specifically requested above.**

Instead:

1. Inspect the existing codebase.
2. Identify the current modules and database structure.
3. Reuse existing components and functionality.
4. Add the requested features.
5. Connect the modules properly.
6. Implement the actual subscription restrictions.
7. Ensure VAT is 18%.
8. Improve/simplify POS.
9. Add proper Inventory/Stock management.
10. Add invoice printing.
11. Add the Feedback system.
12. Test all workflows.
13. Fix any errors caused by the modifications.
14. Ensure existing functionality continues working.

The final result should feel like the **same existing application, professionally upgraded**, not a completely different system.

### Priority

The most important requirements are:

**1. Inventory/Stock Management**
**2. Sales Module**
**3. Purchases Module**
**4. Product/Item Management with Images**
**5. Subscription Rules & Limits**
**6. Invoice Printing**
**7. Feedback System**
**8. 18% VAT**
**9. Simplified POS**

All modules must work together as one complete business management system.

**please show me where yu work on so that i can edit it on my cpanel**